#include "bisen_energy.h"

namespace bisen {
namespace {

EnergyBand classify_energy(uint32_t vcap_millivolts) {
    if (vcap_millivolts >=
        kBenchEnergyPolicy.chunk_1000_min_vcap_millivolts) {
        return EnergyBand::kChunk1000;
    }
    if (vcap_millivolts >=
        kBenchEnergyPolicy.chunk_500_min_vcap_millivolts) {
        return EnergyBand::kChunk500;
    }
    if (vcap_millivolts >=
        kBenchEnergyPolicy.chunk_100_min_vcap_millivolts) {
        return EnergyBand::kChunk100;
    }
    return EnergyBand::kWait;
}

uint32_t lower_boundary(EnergyBand band) {
    switch (band) {
        case EnergyBand::kChunk1000:
            return kBenchEnergyPolicy.chunk_1000_min_vcap_millivolts;
        case EnergyBand::kChunk500:
            return kBenchEnergyPolicy.chunk_500_min_vcap_millivolts;
        case EnergyBand::kChunk100:
            return kBenchEnergyPolicy.chunk_100_min_vcap_millivolts;
        case EnergyBand::kWait:
            return 0u;
    }
    return 0u;
}

}  // namespace

EnergyStatus choose_energy_policy(const EnergyObservation &observation,
                                  EnergyDecision *decision) {
    if (decision == nullptr || !observation.valid) {
        return EnergyStatus::kHardwareUnresolved;
    }

    *decision = {};
    const uint32_t vcap = observation.policy_vcap_millivolts;
    const EnergyBand classified = classify_energy(vcap);
    decision->band = classified;
    if (observation.previous_band != classified) {
        const bool falling = static_cast<uint8_t>(classified) <
                             static_cast<uint8_t>(observation.previous_band);
        const uint32_t boundary =
            falling ? lower_boundary(observation.previous_band)
                    : lower_boundary(classified);
        const bool retain = falling
            ? (vcap + kBenchEnergyPolicy.hysteresis_millivolts >= boundary)
            : (vcap < boundary +
                          kBenchEnergyPolicy.hysteresis_millivolts);
        if (retain) {
            decision->band = observation.previous_band;
        }
    }
    switch (decision->band) {
        case EnergyBand::kChunk1000:
            decision->chunk_pixels = kBenchEnergyPolicy.chunk_1000_pixels;
            break;
        case EnergyBand::kChunk500:
            decision->chunk_pixels = kBenchEnergyPolicy.chunk_500_pixels;
            break;
        case EnergyBand::kChunk100:
            decision->chunk_pixels = kBenchEnergyPolicy.chunk_100_pixels;
            break;
        case EnergyBand::kWait:
            decision->chunk_pixels = 0u;
            break;
    }
    decision->restore_allowed =
        vcap >= kBenchEnergyPolicy.resume_vcap_millivolts;
    // No independent temperature-energy threshold has been measured. Reuse
    // the more conservative, documented resume threshold for this bench phase.
    decision->temperature_allowed = decision->restore_allowed;
    decision->compute_allowed =
        BISEN_ENABLE_COMPUTE_WORKLOAD != 0 &&
        vcap >= kBenchEnergyPolicy.chunk_100_min_vcap_millivolts &&
        decision->chunk_pixels != 0u;
    decision->low_energy_checkpoint_region =
        vcap <= kBenchEnergyPolicy.checkpoint_trigger_vcap_millivolts;
    decision->below_sleep_floor =
        vcap < kBenchEnergyPolicy.sleep_below_vcap_millivolts;
    return EnergyStatus::kReady;
}

LowEnergyCheckpointAction choose_low_energy_checkpoint_action(
    const EnergyDecision &decision, bool context_dirty, bool job_complete,
    bool failure_latched) {
    // Match the MSP430 scheduler's intent: only incomplete, dirty work is a
    // recovery checkpoint candidate when useful computation can no longer
    // proceed. Completion is not itself a persistence event.
    if (!decision.low_energy_checkpoint_region || !context_dirty ||
        job_complete || failure_latched) {
        return LowEnergyCheckpointAction::kNone;
    }
    return LowEnergyCheckpointAction::kWrite;
}

}  // namespace bisen
